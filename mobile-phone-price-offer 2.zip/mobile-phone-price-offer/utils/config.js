const APP_ID = 'wxd468ce20c19da954'
const INVALID_TOKEN = 'illegal_access_token'
const API_HOST = 'https://apple110.wpweixin.com/api2/'
module.exports = {
    APP_ID,
    INVALID_TOKEN,
    API_HOST
}
