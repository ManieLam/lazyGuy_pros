var API_PATH = getApp().globalData.API_PATH;

// 请求方式为GET
var apiRequest = function(url, data) {
    wx.showLoading({
        title: '加载中',
    })
    setTimeout(function() {
        wx.hideLoading()
    }, 1000)
    var promise = new Promise(function(resolve, reject) {
        wx.request({
            url: API_PATH + url,
            data: data,
            method: 'GET',
            header: { 'content-type': 'application/json' },
            success: resolve,
            fail: reject
        })
    });
    return promise;
};

var apiRequest2 = function(url, data) {
    // wx.showLoading({
    //     title: '加载中',
    // })
    // setTimeout(function() {
    //     wx.hideLoading()
    // }, 1000)
    var promise = new Promise(function(resolve, reject) {
        wx.request({
            url: API_PATH + url,
            data: data,
            method: 'GET',
            header: { 'content-type': 'application/json' },
            success: resolve,
            fail: reject
        })
    });
    return promise;
};

// 请求方式为POST
var apiPost = function(url, data) {
    var promise = new Promise(function(resolve, reject) {
        wx.request({
            url: API_PATH + url,
            data: data,
            method: 'POST',
            success: resolve,
            fail: reject
        })
    });
    return promise;
};

export default {
    apiRequest,
    apiRequest2,
    apiPost
}
