//app.js
import Auth from "utils/auth"

App({
    onLaunch: function(options) {
        this.getDeviceInfo();
    },

    onShow: function(options) {
        this.globalData.scene = options.scene

        if ( options.scene == 1044 ) {
            this.globalData.shareTicket = options.shareTicket
        }

    },

    getDeviceInfo() {
        let that = this;
        wx.getSystemInfo({
            success: function(res) {
                console.log('3333', res);
                if (res.platform == 'android') {
                    var bg_img_src = '/images/android_banner_bj.jpg'
                } else if (res.platform == 'ios') {
                    var bg_img_src = '/images/iphone_banner_bj.jpg'
                } else {
                    var bg_img_src = '/images/android_banner_bj.jpg'
                }

                if (res.platform == 'android') {
                    var platform = 'Android';
                } else if (res.platform == 'ios') {
                    var platform = 'iOS';
                } else {
                    var platform = res.platform;
                }

                if (res.language == 'zh_CN') {
                    var lan = "简体中文";
                } else if (res.language == 'zh_HK') {
                    var lan = "繁体中文";
                } else if (res.language == 'zh_TW') {
                    var lan = "繁体中文";
                } else {
                    var lan = res.language;
                }
                let data = {
                    src: bg_img_src,
                    model: res.model.replace(/\(.*|<.*?\>|\)/g, ''),
                    platform: platform,
                    system: res.system,
                    version: res.version,
                    language: lan
                }
                // console.log('deviceInfo', data);
                that.globalData.deviceInfo = data
            }
        })
    },

    getUserInfo: function(cb) {
        var that = this
        if (this.globalData.userInfo) {
            typeof cb == "function" && cb(this.globalData.userInfo)
        } else {
            //调用登录接口
            wx.login({
                success: function() {
                    wx.getUserInfo({
                        success: function(res) {
                            that.globalData.userInfo = res.userInfo
                            typeof cb == "function" && cb(that.globalData.userInfo)
                        }
                    })
                }
            })
        }
    },

    globalData: {
        userInfo: null,
        // deviceInfo: null,
        shareTicket: null,
        scene:0,
        API_PATH: 'https://apple110.wpweixin.com'
    }
})
