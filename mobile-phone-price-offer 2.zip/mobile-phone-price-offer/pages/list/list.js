//category.js
import util from '../../utils/api';

Page({

    // 定义数据
    data: {
        title: '',
        share_path:'/pages/list/list',
        content: '',
        newsList: [],
        phone_url: '',
        mask: true,
        curr_id: ''

    },

    // 分享页面功能
    onShareAppMessage: function() {
        return {
            title: this.data.title,
            path: this.data.share_path,
        }
    },

    // 页面onLoad
    onLoad: function(options) {
        var that = this;
        util.apiRequest('/api2/get_wxapp_phone_list.json').then(
            function(res) {
                if (res.statusCode == 200) {
                    console.log(res);
                    wx.setNavigationBarTitle({
                      title: res.data.title
                    });
                    that.setData({
                        title: res.data.title,
                        content: res.data.content,
                        newsList: res.data.list,
                        phone_url: res.data.list.url
                    })
                } else {

                }
            },
            function(res) {
                console.log('fail', res);

            }
        );
    },
})
