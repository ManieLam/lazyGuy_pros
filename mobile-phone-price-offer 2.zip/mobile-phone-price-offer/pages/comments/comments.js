import util from '../../utils/api';
Page({
  data: {
    share_path: '/pages/comments/comments',
    content: {}
  },
  onLoad: function (options) {
    var that = this;
    that.setData({
      share_path:'/pages/comments/comments?id='+options.id
    })
    util.apiRequest('/api2/get_wxapp_phone.json?id='+options.id).then(
      function (res) {
        if (res.statusCode == 200) {
          // console.log('success', res);
          that.setData({
            content: res.data
          })
          wx.hideToast();
          wx.setNavigationBarTitle({
            title: res.data.name
          })
          // console.log(that.data.content);
        } else {
          wx.showLoading({
            title: '加载有误!',
          })
        }
      },
      function (res) {
        wx.showLoading({
          title: '加载有误!',
        })
      }
    );
  },
  onShareAppMessage: function () {
    return {
      title: this.data.content.name,
      path: this.data.share_path,
    }
  },
  copyUrlTap(){
    // console.log(11);

     // 复制功能
    var _this=this;
    // console.log(111,this.data.content.url);
    wx.setClipboardData({
      data: _this.data.content.url,
      success: function (res) {
        wx.getClipboardData({
          success: function (res) {
            wx.showModal({
              title: '购买链接复制成功',
              content: '请粘贴链接至浏览器打开！',
              showCancel: false,
              success: function (res) {
                if (res.confirm) {
                  // console.log(url)
                }
              }
            })
          }
        })
      }
    })


  },
   back_home:function(){
        wx.reLaunch({
        url: '/pages/category/category'
        })
    }
})