import util from '../../utils/api';
Page({
    data: {
        title: '手机榜单',
        share_path:'/pages/category/category',
        newsList: [],
    },
    onLoad: function(options) {
       var that = this;
		util.apiRequest('/api2/get_wxapp_phone_lists.json',{id:options.id}).then(
			function(res){
				if(res.statusCode == 200){
					 console.log('success',res);
					that.setData({
                        newsList:res.data
					})
                    wx.hideToast();
                    console.log(that.data.newsList);
				}else{
                    wx.showLoading({
                         title: '加载有误',
                    })
				}
			},
			function(res){
				 wx.showLoading({
                    title: '加载有误',
                 })
			}
		);
    },
    onShareAppMessage: function() {
        return {
            title: this.data.title,
            path: this.data.share_path,
        }
    }
})
