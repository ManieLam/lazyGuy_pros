import util from '../../utils/api';
Page({
  data: {
    share_path:"/pages/annual_list/annual_list",
    parameter_id:'',//页面id的
    content: {}
  },
  onLoad: function (options) {
    console.log(options)
    var that = this;
    this.setData({
      parameter_id:options.id,
      share_path: '/pages/annual_list/annual_list?id='+ options.id
      
    });
    util.apiRequest('/api2/get_wxapp_phone_list.json?id='+that.data.parameter_id).then(
      function (res) {
        if (res.statusCode == 200) {
          console.log('success', res);
          var content=res.data;
          for(var i=0;i<content.list.length;i++){
              content.list[i].more=true;
          }
          that.setData({
            content: content,

          })
          wx.hideToast();
          wx.setNavigationBarTitle({
            title: res.data.title
          })
          console.log(that.data.content);
        } else {
          wx.showLoading({
            title: '加载有误',
          })
        }
      },
      function (res) {
        wx.showLoading({
          title: '加载有误',
        })
      }
    ); 
  },
  onShareAppMessage: function () {
    return {
      title: this.data.content.title,
      path: this.data.share_path,
    }
  },
   back_home:function(){
        wx.reLaunch({
        url: '/pages/category/category'
        })
    }
})