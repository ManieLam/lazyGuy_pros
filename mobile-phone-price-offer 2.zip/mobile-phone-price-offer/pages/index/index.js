//index.js
//获取应用实例
import util from '../../utils/api';
import Auth from '../../utils/auth';

Page({

    // 定义数据
    data: {
        showMask: false,
        scene: getApp().globalData.scene,
        snInfo: [
            { model: '', platform: '', system: '', version: '', language: '' }
        ],
        adds: '',
        weapp: '',
        items: [],
        phoneInfo: getApp().globalData.deviceInfo,
        phoneList: true,
    },


    // 关闭mask
    closeMask: function() {
        this.setData({
            showMask: false
        })
    },


    onShow(res) {

        wx.showShareMenu({ withShareTicket: true });
        const that = this;

        this.setData({ scene: getApp().globalData.scene })

        console.log('2333', getApp().globalData.scene);

        if (getApp().globalData.scene == 1044) {

            const shareTicket = getApp().globalData.shareTicket
            wx.login({
                fail() {
                    wx.hideLoading();
                },
                success: function(res) {
                    const code = res.code
                    wx.showLoading({title:"加载中"});
                    Auth.checkOrLogin().then(res => {
                        wx.getShareInfo({
                            shareTicket: shareTicket,
                            success: function(res) {
                                const iv = res.iv;
                                const encrypted_data = res.encryptedData;
                                const data = { iv, code, encrypted_data, phone: getApp().globalData.deviceInfo.model }
                                util.apiPost('/api2/group.phones.json', data).then(res => {
                                    that.setData({ items: res.data.phones })
                                    wx.hideLoading();
                                }, e => {
                                    console.log('ee', e);
                                    wx.hideLoading();
                                })
                            },
                            fail() {
                                wx.hideLoading();
                            }
                        });
                    }, e => {
                        wx.showModal({
                            title: '温馨提示',
                            content: '您必须授权才可以操作',
                            fail() {
                                wx.hideLoading();
                            },
                            success: function(res) {
                                if (res.confirm) {
                                    wx.openSetting({
                                        fail() {
                                            wx.hideLoading();
                                        },
                                        success() {
                                            wx.getShareInfo({
                                                shareTicket: shareTicket,
                                                fail() {
                                                    wx.hideLoading();
                                                },
                                                success: function(res) {
                                                    const iv = res.iv;
                                                    const encrypted_data = res.encryptedData;
                                                    const data = { iv, code, encrypted_data, phone: getApp().globalData.deviceInfo.model }
                                                    util.apiPost('/api2/group.phones.json', data).then(res => {
                                                        that.setData({ items: res.data.phones })
                                                        wx.hideLoading();
                                                    }, e => {
                                                        console.log('ee', e);
                                                        wx.hideLoading();
                                                    })
                                                }
                                            });
                                        }
                                    });
                                }
                            }
                        })
                    });
                }
            });
        }
    },

    // 页面onLoad
    onLoad: function(res) {
        var that = this;
        console.log('onLoad', res);
        util.apiRequest2('/api2/get_wxapp_banner.json').then(
            function(res) {
                if (res.statusCode == 200) {
                    // console.log('success', res);
                    that.setData({
                        adds: res.data.banner,
                        weapp: res.data.weapp
                    })
                    wx.hideToast();
                } else {

                }
            },
            function(res) {
                console.log('fail', res);

            }
        );

    },

    // 预览图片功能
    previewImageTap: function(e) {
        if (wx.navigateToMiniProgram) {
            wx.navigateToMiniProgram({
                appId: this.data.weapp.appid,
                path: this.data.weapp.path,
                envVersion: this.data.weapp.version,
                success(res) {
                    // 打开成功
                    console.log('跳转成功');
                }
            })
        } else {
            console.log("不兼容程序跳转")
            wx.previewImage({
                current: this.data.adds,
                urls: [this.data.adds]
            })
        }
    },

    // 分享页面功能
    onShareAppMessage: function() {
        return {
            title: '看看大家都在用什么手机？',
            path: '/pages/index/index',
            success(res) {
                console.log('share', res)
            }
        }
    },


})
